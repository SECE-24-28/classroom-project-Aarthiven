const express = require('express')
const app = express()
const bodyparser = require('body-parser')
const exhbs = require('express-handlebars')

let msg = "Aarthi"



app.engine('hbs', exhbs.engine({
    layoutsDir: 'viewsfound',
    defaultLayout: 'main',
    extname: 'hbs'
}))
app.use(bodyparser.urlencoded({
    extended: true
}))

app.set('view engine', 'hbs')
app.set('views', 'viewsfound')

const dbo = require('./db')

app.post('/store_book',async(req,res)=>{
    let database=await dbo.getdatabase()
    const collection=database.collection('books')
    let bookdata={title:req.body.title,
        author:req.body.author}
    await collection.insertOne(bookdata)
    return res.redirect('/?status=1')
})

app.get('/', async (req, res) => {
    let database = await dbo.getdatabase()   
    const collection = database.collection('books')
    const books = await collection.find({})
    let mydata = await books.toArray()

    switch (req.query.status) {
        case '1':
            msg = "Book added successfully"
            break;
        default:
            break;
    }

    res.render('main', { msg, mydata })
})



app.listen(2007, () => {
    console.log("listening to the podecast")
})