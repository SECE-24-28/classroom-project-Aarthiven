const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;

let database;

async function getdatabase() {
    if (database) {
        return database;  // Reuse the existing connection
    }

    const client = await MongoClient.connect('mongodb://127.0.0.1:27017');

    database = client.db('bookdemo1');

    if (!database) {
        console.log("not connected");
    }

    return database;
}

module.exports = { getdatabase };
